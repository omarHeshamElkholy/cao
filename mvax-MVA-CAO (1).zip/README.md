# Introduction 
I am a template for a standard dal microservice. 

# Getting Started
project running steps :

1- rename mvax-ms-skeleton-svc module name to the microservice needed name and must  rename it in the main project pom file in the module pare
like :     <modules>
<module>mvax-ms-skeleton-svc</module>
</modules>
2- need to rename some attributes in the microservice project pom file :
- artifactId
- name
- mainClass in the "spring-boot-maven-plugin" plugin with the main class
  3- rename the main class with the microservice name
  4- rename the user and group in the docker file
  5- run mvn clean install command
  6- run the project with the configuration of java application like mvax-api
  7- try test api with this curl :
- **** didn't forget to change the microserviceName with the name which changed from the properties file from the (( server.servlet.context-path)) property
- curl --location --request GET 'https://localhost:8443/app/[[microserviceName]]/api/v1/test-api' \
  --header 'Subscription: 01126399297' \
  --header 'authenticationToken: PJWkPZbGyVnb17DhVLa+khgIVBOayrd2wvyPJqntKRKVfozW0V+3huf03tr9kTryAbs+b+HJNqgW3/LPv8Uwu2gzjoZbm52szemdZqUXZbLACArKoqcfhrwDzd5uKluRaVpf2dS0fNapHq7S6INHOdKyuhPDRsXtoIC9RAt1nQqEzx67rAFbab4Gu/qI2OdQYWQgLNfCZAbmDe64oOOTN8fEEr+hygRZWIvG3TthfSjBpnFhSE8KMrwMemp2AZEuGbUgdnLX8zSTXzRLhkt0/D/ZlpNDspXIYqmUZ/2hL7k3xVLxjpQx1W/dYuW/EjxpfwPQ/DZ3wRwv4dVRvpey8g=='
  8- and health check api with this curl :
- curl --location --request GET 'https://localhost:8443/app/[[microserviceName]]/actuator/health'
-------------------------------------------------------------------------------------------------------
deployment steps :
1- add variable group for the release microservice deployment
2- add variable to this variable group (( microserviceName ))  with the microservice name
3- add variable to this variable group ((microserviceContextPath )) to define the context path of the microservice
4- change the listener rule for the api-docs with the context path of the microservice in the service template file 
like : 
from "/skeleton/api-docs" to "/[[microserviceName]]/api-docs"
5- change the priorities  values of the service fragate stack and listener rules 

# Build and Test
TODO: Describe and show how to build your code and run the tests. 

# Contribute
TODO: Explain how other users and developers can contribute to make your code better. 

If you want to learn more about creating good readme files then refer the following [guidelines](https://www.visualstudio.com/en-us/docs/git/create-a-readme). You can also seek inspiration from the below readme files:
- [ASP.NET Core](https://github.com/aspnet/Home)
- [Visual Studio Code](https://github.com/Microsoft/vscode)
- [Chakra Core](https://github.com/Microsoft/ChakraCore)