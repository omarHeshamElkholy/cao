#!/bin/sh

# Specify startup options
JAVA_OPTS="\
-Drun_mvax=true \
-Dspring.profiles.active=${environment} \
-Dlog4j2.formatMsgNoLookups=true \
-Xms${javaMemoryMs} \
-Xmx${javaMemoryMx} \
-XX:+HeapDumpOnOutOfMemoryError \
-XX:HeapDumpPath=/tmp/ \
-XX:-UseContainerSupport \
-Dhttp.proxyHost=${dxl_outbound_proxy_host} \
-Dhttp.proxyPort=${dxl_outbound_proxy_port} \
-Dhttps.proxyHost=${dxl_outbound_proxy_host} \
-Dhttps.proxyPort=${dxl_outbound_proxy_port} \
-Dhttp.nonProxyHosts=${NoProxyJava} \
\
"

echo "{\"message\":\"Using JAVA_OPTS: ${JAVA_OPTS}\",\"level\":\"INFO\",\"logger_name\":\"startup.sh\",\"thread_name\":\"main\"}"


if [[ "${DdogFlag}" == "true" ]]; then
  JAVA_OPTS="${JAVA_OPTS} -javaagent:/apps/datadog/dd-java-agent.jar"
  export DD_SERVICE_NAME=${MSNAME}
  export DD_TRACE_AGENT_PORT=8126
  export DD_SERVICE=${MSNAME}
  export DD_VERSION=${VERSION} # Version can be the build ID
  export DD_JMXFETCH_ENABLED="true"
  export DD_LOGS_INJECTION="true"
  export DD_TRACE_SPLIT_BY_TAGS="aws.service"

fi

exec java $JAVA_OPTS -jar /apps/sb/$JAR_NAME
