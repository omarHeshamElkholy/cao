package com.vf.mvax.skeleton.security;

import com.vf.mvax.common.api.configuration.security.JwtSecurityKeys;
import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Data
public class SecurityKeysImpl implements JwtSecurityKeys {
    @Value("${mvax.key.active}")
    private String activeKey;
    @Value("${mvax.key.inactive}")
    private String inactiveKey;
}
