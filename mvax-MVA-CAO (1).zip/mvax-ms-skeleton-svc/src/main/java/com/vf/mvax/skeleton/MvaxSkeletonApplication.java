package com.vf.mvax.skeleton;


import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.vf.mvax.common.api.filter.AuthenticationFilter;
import com.vf.mvax.common.api.interceptor.MvaxAuditInterceptor;

@SpringBootApplication
@ComponentScan(basePackages = {"com.vf.mvax"})
@PropertySource(value = {"classpath:application.properties","classpath:core-application.properties","classpath:log-application.properties"})
@EnableCaching
public class MvaxSkeletonApplication implements WebMvcConfigurer{

	public static Logger logger= LoggerFactory.getLogger(MvaxSkeletonApplication.class);
	
	Environment environment;
	private final MvaxAuditInterceptor auditInterceptor;   
    @Value("${admintool.domain.url}")
    public String admintoolUrl;
    
    public MvaxSkeletonApplication(Environment environment, MvaxAuditInterceptor auditInterceptor) {
        this.environment = environment;
        this.auditInterceptor = auditInterceptor;
    }

	public static void main(String[] args) {
		logger.info("app is started .....");
		new SpringApplicationBuilder(MvaxSkeletonApplication.class).web(WebApplicationType.SERVLET).run(args);

	}
	
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(auditInterceptor).addPathPatterns("/api/**");
    }

    @Bean
    public ModelMapper modelMapper() {
        return new ModelMapper();
    }

    @Bean
    WebMvcConfigurer configurer () {
        return new WebMvcConfigurer() {
            @Override
            public void addResourceHandlers (ResourceHandlerRegistry registry) {
                registry.addResourceHandler("/files/**").
                        addResourceLocations("classpath:json-responses/");
            }
        };
    }   
    
    @Bean
    public CorsFilter corsFilter() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        if(!"NA".equals(admintoolUrl)) {
            // Allow anyone and anything access. Probably ok for Swagger spec
            CorsConfiguration config = new CorsConfiguration();
            config.setAllowCredentials(true);
            config.addAllowedOrigin(admintoolUrl);
            config.addAllowedHeader("*");
            config.addAllowedMethod("*");

            source.registerCorsConfiguration("/**", config);
        }
        return new CorsFilter(source);
    }
    
    @Bean
    public TaskExecutor taskExecutor() {
        return new ThreadPoolTaskExecutor();
    }
  
    @Bean
    public FilterRegistrationBean<AuthenticationFilter> authenticationFilter(){
        FilterRegistrationBean<AuthenticationFilter> registrationBean
                = new FilterRegistrationBean<>();

        registrationBean.setFilter(new AuthenticationFilter(environment));
        registrationBean.addUrlPatterns("/api/*");

        return registrationBean;
    }

 

}
