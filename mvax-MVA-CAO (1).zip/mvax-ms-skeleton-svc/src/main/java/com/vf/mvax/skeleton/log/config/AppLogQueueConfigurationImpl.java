package com.vf.mvax.skeleton.log.config;

import com.vf.mvax.base.log.config.AppLogQueueConfiguration;
import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Data
public class AppLogQueueConfigurationImpl implements AppLogQueueConfiguration {

    @Value("${app.logging.queue.url}")
    private String appLoggingQueueURL;

}
