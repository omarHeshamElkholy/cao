package com.vf.mvax.skeleton.service;


import org.springframework.stereotype.Service;

@Service
public class TestService {


    public String getTestApiStringValue(){
        return "test api is working fine ...";
    }
}
