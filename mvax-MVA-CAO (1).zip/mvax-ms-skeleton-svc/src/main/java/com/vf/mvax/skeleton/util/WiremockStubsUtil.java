package com.vf.mvax.skeleton.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.log4j.Log4j2;
import okhttp3.*;

import java.io.IOException;

/**
 * @author IsmaielK
 */
@Log4j2
public final class WiremockStubsUtil {

    public static final String HOST_URL = "http://localhost:8080";
    public static final String AUTHORIZATION = "authorization";

    public static final OkHttpClient client = new OkHttpClient();


    private WiremockStubsUtil() {
    }

    private static <V> V callWiremockStubs(Class<V> obj, Request request) {
        ResponseBody responseBody;
        try {
            responseBody = client.newCall(request).execute().body();
        } catch (IOException e) {
            log.error(String.format("Calling wiremock stubs with request url:%s failed", request.url()));
            return null;
        }
        ObjectMapper objectMapper = new ObjectMapper();
        V object;
        try {
            object = objectMapper.readValue(responseBody != null ? responseBody.string() : null, obj);
        } catch (Exception e) {
            log.error(String.format("Wirewmock stubs Mapping of request:%s failed", request.url()));
            return null;
        }
        return object;

    }

}
