package com.vf.mvax.skeleton.log.config;


import com.vf.mvax.base.log.config.ApiLog;
import com.vf.mvax.base.log.config.ApiLogConfiguration;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@PropertySources({
        @PropertySource(value = "classpath:mvax-skeleton-api-log-endpoints/mvax-skeleton-api-log-endpoints.yml", name = "ApiLogConfiguration", factory = YamlPropertyLoaderFactory.class, ignoreResourceNotFound = true),
        @PropertySource(value = "classpath:mvax-skeleton-api-log-endpoints/mvax-skeleton-api-log-endpoints-${spring.profiles.active}.yml", name = "ApiLogConfiguration", factory = YamlPropertyLoaderFactory.class, ignoreResourceNotFound = true)
})
@ConfigurationProperties(prefix = "mvax.api.log")
@Data
public class ApiLogConfigurationImpl implements ApiLogConfiguration {

    private List<ApiLog> mvaxApiLogList;
    private List<ApiLog> dalApiLogList;

    @Override
    public ApiLog getApiByName(String dalApiLogName) {
        return dalApiLogList.stream().filter(apiLog -> apiLog.getName().equals(dalApiLogName)).findFirst().orElse(null);
    }

    @Override
    public ApiLog getApiByUri(String mvaxURI) {
        return mvaxApiLogList.stream().filter(apiLog -> apiLog.getUri().equals(mvaxURI)).findFirst().orElse(null);
    }
}
