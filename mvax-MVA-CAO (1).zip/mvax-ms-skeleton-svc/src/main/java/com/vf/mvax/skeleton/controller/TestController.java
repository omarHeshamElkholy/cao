package com.vf.mvax.skeleton.controller;



import com.vf.mvax.skeleton.service.TestService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.vf.mvax.common.api.controller.AbstractController;


@RestController
@CrossOrigin
@RequestMapping("/api")
public class TestController extends AbstractController {






	@Autowired
	TestService testService;



	
	@GetMapping("v1/test-api")
	@ResponseBody
	public ResponseEntity testApi(
			@RequestHeader(value = "Subscription", required = true) String subscription,
			@RequestAttribute(value = "GUID", required = false) String guid) {

		return ResponseEntity.ok(testService.getTestApiStringValue());

	}
}
