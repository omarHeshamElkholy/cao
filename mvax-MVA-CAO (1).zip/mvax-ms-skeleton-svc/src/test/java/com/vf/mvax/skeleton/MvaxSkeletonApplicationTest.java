package com.vf.mvax.skeleton;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvaxApplicationTests {

	@Test
	void contextLoads() {
	}

}
