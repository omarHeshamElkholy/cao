import './App.css';
import Search from './components/Search';
import React from 'react';
import InvestigationForm from "./components/InvestigationForm";
import Header from "./components/Header";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Result from './components/Result';


function App() {

  return (
    <Router>
      <div className="background">
        <Header />
        <Routes>
          <Route exact path="/" element={<InvestigationForm />} />
          <Route path="/search-results" element={<Search />} />
          <Route path="/results" element={<Result />} />

        </Routes>
      </div>
    </Router>
  );
}

export default App;


















