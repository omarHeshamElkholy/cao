import React from 'react';
import "./Header.css";
import { useNavigate } from 'react-router-dom';
// import logo from '../assets/images/logo.png';
import Vodafone from '../assets/images/Vodafone.png';
const Header = () => {
    const navigate = useNavigate();
    const onSearch = () => {
        // navigate to search results page
        navigate('/search-results');
    };
    const handleReportIssue = () => {
        // navigate to form results page
        navigate('/');
    };
    return (
        <>
            <div className="heading">
                <div style={{ width: '40%' }}>
                    <div className="vodafone-logo-container">
                        <img src={Vodafone} className="vodafone-logo" />
                    </div>
                </div>
                <div className="button-header">
                    <button className="button" type="form" id="form-button" onClick={handleReportIssue}>Report an issue</button>
                    <button className="button" type="search" id="Search" onClick={onSearch} >Search </button>
                </div>
            </div>


        </>

    )
}
export default Header;

