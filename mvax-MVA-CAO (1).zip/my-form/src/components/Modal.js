import { useState } from 'react';
import "./Modal.css";
const Modal = ({ onClose, children }) => {

    const closeModal = () => onClose(false);
    const [refNumber, setRefNumber] = useState('');

    return (
        <>

            <div className="modal-overlay">
                <div className="modal">
                    <button className="modal-close" onClick={closeModal}>x</button>
                    {/* {children} */}
                    {typeof children === 'function' ? children() : children}
                </div>
            </div>

        </>
    );
};

export default Modal;