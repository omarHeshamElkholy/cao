import React, { useState } from 'react';
import './InvestigationForm.css';
import { useForm } from 'react-hook-form';
import Modal from './Modal';
import logo from '../assets/images/logo.png';
// import check from '../assets/images/check.png';
//for route to result page after submit the form
// import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';




const InvestigationForm = () => {
    const navigate = useNavigate();
    const [refNumber, setRefNumber] = useState('');
    const [isOpen, setIsOpen] = useState(false);
    const [formData, setFormData] = useState('');
    // const [showSuccessModal, setShowSuccessModal] = useState(false);

    const {
        register,
        handleSubmit,
        formState: { errors },
        reset
    } = useForm();
    const onClickConfirm = () => {

        sendInvestigationFormData();
    };
    const sendInvestigationFormData = async () => {
        // setShowSuccessModal(true); //for test
        setIsOpen(false)
        try {
            const response = await fetch('https://api.example.com/submit-form', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
                //the data that send to backend
            });
            const responseData = await response.json();
            //response from user
            setRefNumber(responseData);
            // setShowSuccessModal(true);
            reset();
            console.log(responseData);
        } catch (error) { //for the error from api it not important for now
            console.error(error);
        }
        finally {  //after the request finish 
            // navigate to  results page
            navigate('/results');
        }
    }
    //save the form data
    const data = [
        { label: 'Customer contact number:', value: formData.name },
        { label: 'Last date of issue', value: formData.issueDate },
        { label: 'segment', value: formData.segment },
        { label: 'Email', value: formData.email },
        { label: 'ErrorCode', value: formData.errorCode },
        { label: 'Journey', value: formData.journey },
        { label: 'Issue Description', value: formData.issueDescription },
    ];
    //the funcation that return user data(appear data on screen) inside model content
    const CustomerDetails = ({ onClickConfirm }) => {
        return (
            <>
                {/* loop on user data that appear */}
                {data.map((item, index) => (
                    <div className='customer-details-data' key={index}>
                        <p>{item.label}</p>
                        <div> {item.value}</div>
                    </div>
                ))}
                <div className='confirmbutton-container'>
                    <button className='backbutton' onClick={() => setIsOpen(false)}>
                        Back
                    </button>
                    <button className='confirmbutton' onClick={onClickConfirm}>
                        Confirm
                    </button>

                </div>
                {/* confirm button for redirect to other page */}
                {/* <p>your reference number is 344567879888 </p>; */}
            </>
        );
    };
    const onSubmit = (data) => {
        if (Object.keys(errors).length === 0) { // check if there are no errors
            setFormData(data);
            setIsOpen(true);
            //when user enter submit open first popupwindow with data

        }
    }
    // const onClickBack = () => {
    //     setShowSuccessModal(false);
    // }
    return <>
        <div className="container">
            <div className="logo-container">
                <img src={logo} className="logo" />
                <h2 className="heading1">Please,Fill the following information:</h2>
            </div>
            <div>
                <form onSubmit={handleSubmit(onSubmit)}>
                    {/* it handle submit it is built in func */}
                    <label htmlFor="name">Customer Contact Number:<span className="error">*</span></label>

                    <input type="text" id="name" name="name" {...register('name', { required: true })} />
                    {errors.name && errors.name.type === "required" && <span className="error">please enter the error code appear to you</span>}

                    <label htmlFor="issueDate">last date of issue:<span className="error">*</span></label>
                    <input type="date" id="issueDate" name="issueDate"  {...register('issueDate', { required: true })} />
                    {errors.name && errors.name.type === "required" && <span className="error">This field is required</span>}

                    <label htmlFor="user segment">Segment:</label>
                    {/* <input type="text" id="segment" name="segment" {...register('segment')} /> */}
                    <div className="select-box">
                        <select id="segment" {...register('segment')}>
                            <option value="Other">Other</option>
                            <option value="Topup">Plan</option>
                            <option value="Billing">Billing</option>
                            <option value="Login">Login</option>
                        </select>
                    </div>


                    <label htmlFor="Email">Email:<span className="error">*</span></label>
                    <input type="email" id="email" name="email"  {...register('email', { pattern: /^\S+@\S+$/i })} />

                    <label htmlFor="errorCode">Error code:<span className="error">*</span></label>
                    {/* <input type="number" max="9999" id="errorCode" name="errorCode" {...register('errorCode')} /> */}
                    <div className="select-box">
                        <select type="number" max="9999" id="errorCode" name="errorCode" {...register('errorCode')}>
                            <option value="Other">4300</option>
                            <option value="Topup">2500</option>
                            <option value="Billing">5604</option>
                            <option value="Login">5602</option>
                        </select>
                    </div>



                    <label htmlFor="dog-names">Journey:</label>
                    <div className="select-box">
                        <select id="journey" {...register('journey')}>
                            <option value="Other">Other</option>
                            <option value="Topup">Plan</option>
                            <option value="Billing">Billing</option>
                            <option value="Login">Login</option>
                        </select>


                        <label htmlFor="issueDescription">Issue Description:<span className="error">*</span></label>
                        <textarea
                            type="text"
                            id="issueDescription"
                            name="issueDescription"
                            rows="5"
                            {...register('issueDescription', { required: true })}
                        ></textarea>
                        {errors.name && errors.name.type === "required" && <span className="error">This field is required</span>}
                    </div>
                    <div className="button-container">
                        {/* <button type="button" id="clear-button">Clear</button> */}
                        <button type="submit">submit</button>
                    </div>
                    <div id="loader" className="hidden"></div>
                </form>
                <div className="formsubmition">
                    {
                        //first popup window that contain data
                        isOpen && <Modal onClose={setIsOpen} children={<CustomerDetails onClickConfirm={onClickConfirm} />} />
                        //  <Modal onClose={setIsOpen} children={CustomerDetails} />
                    }

                    {/* {showSuccessModal && <Modal onClose={setShowSuccessModal}>

                        <img src={check} className="check" />
                        <p>Ticket has been created succesfully</p>
                        {refNumber}
                        <div className="buttonback">
                            <button onClick={onClickBack} >Back to main page</button>
                        </div>
                    </Modal>} */}
                </div>
            </div>
            {/* <div id="formResponseMsg"></div> */}
            {/* </div> */}
            {/* <div className="toast" id="toast-msg">
      <div className="toast-header">
        <div className="toast-body" id="toast-body"></div>
        <button
          type="button"
          className="close"
          data-dismiss="toast"
          aria-label="Close"
        >
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
    </div>  */}

        </div>


    </>

}

export default InvestigationForm;



