
import React, { useState } from 'react';
import './Search.css';
import search from '../assets/images/searchresult.png';
import logo from '../assets/images/logo.png';
import Modal from './Modal';
// import axios from 'axios';



const Search = () => {
    const [ticketNumber, setTicketNumber] = useState('');
    const [customerNumber, setCustomerNumber] = useState('');
    const [searchResults, setSearchResults] = useState('');
    const [showSearchResultsModal, setShowSearchResultsModal] = useState(false);
    const [shownResultData, setShownResultData] = useState('');
    const [ref, ctn] = useState('');
    const response = ''
    // const ticketNumber = ''
    const onCloseModal = () => {
        setShowSearchResultsModal(false);
    }
    const handleSearch = async (e) => {
        //to show datta
        e.preventDefault();
        // after calling the api should remove this default respone to check the api response
        setShowSearchResultsModal(true);
        // setSearchResults({ status: 'inprogress' });
        showSearchResults('inprogress');
        try {
            console.log(customerNumber)
            //api call and response
            // const response = await fetch(`https://restcountries.com/v3.1/name/egypt`);

            const response = await fetch('http://54.145.73.116:3000/api/cst/getINC', {
                method: 'get',
                headers: {
                    'ctn': `${customerNumber}`,
                    'ref': `${ticketNumber}`
                }
            })
            // axios.request({
            //     url: 'http://54.145.73.116:3000/api/cst/getINC',
            //     method: 'post',
            //     headers: { 'ctn': customerNumber, 'ref': ticketNumber }
            //   })


            const data = await response.json();
            console.log(data);

            // setSearchResults(data[0]);
            setShowSearchResultsModal(true);
            showSearchResults(data[0].status);
        } catch (error) {
            console.error(error);
        }
    }

    {/* conditions for popup windows */ }

    const showSearchResults = (status) => {
        if (status === 'inprogress') {
            const inProgressModal = <div>
                <div className="resolvedticket"><img src={search} className="searchresultlogo" />
                    <p>RF35676234</p>
                    <p>The ticket still <span className="resolvedticket-status">inprogress</span></p>
                </div>
            </div>
            setShownResultData(inProgressModal);
        }
        else if (status === 'resolved') {
            setShownResultData(<p className="resolvedticket"><img src={search} className="searchresultlogo" />The ticket has been resolved \n please advice the customer</p>);
        }
        else if (status === 'doesntexist') {
            setShownResultData(<p className="resolvedticket"><img src={search} className="searchresultlogo" />the ticket you are entered doesn't exist</p>);
        }
        else {
            console.log('No results')
            setShownResultData(<p> No results</p>);
        }
    }


    return (
        <>
            <div className="container">
                <div className="logo-container">
                    <img src={logo} className="logo" />
                </div>
                <div>
                    <h2 className="heading2">Please,Fill the below:</h2>
                </div>
                <form onSubmit={handleSearch}>
                    {/* <div className="searchfunc container"> */}
                    <label htmlFor="name">Ticket Number:<span className="error">*</span></label>
                    <input type="text" placeholder="please enter your cutomer number" value={customerNumber} onChange={(e) => setCustomerNumber(e.target.value)} className="searchinput" />

                    <label htmlFor="name">Customer Number:<span className="error">*</span></label>
                    <input type="text" placeholder="Enter reference number" value={ticketNumber} onChange={(e) => setTicketNumber(e.target.value)} className="searchinput" />

                    {/* <button onClick={handleSearch} className="logosearch"><img src={search} className="searchlogo" /></button> */}

                    <button type='submit' className="logosearch"></button>

                    {/* </div> */}
                    <div className="button-container">
                        {/* <button type="button" id="clear-button">Clear</button> */}
                        <button type="submit">Search</button>
                    </div>
                </form>
                {showSearchResultsModal && <Modal onClose={onCloseModal} children={shownResultData} />}
            </div>
        </>


    );

}
export default Search;