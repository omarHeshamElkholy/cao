import './Result.css';
import React, { useEffect } from 'react';
import check from '../assets/images/check.png';
import logo from '../assets/images/logo.png';


const Result = () => {
    const getResults = async () => {
        try {
            const response = await fetch('https://api.example.com/submit-form', {
                method: 'GET'
            });
            const responseData = await response.json();
            //response from api
            console.log(responseData);
        } catch (error) { //for the error from api it not important for now
            console.error(error);

        }

    }
    useEffect(() => {
        getResults()
    }, [])
    return (
        <div className="container">
            <div className="logo-container">
                <img src={logo} className="logo results-logo" />
            </div>
            <div>

                <img src={check} className="check" />
            </div>
            <div className="resulttext">
                <p>Ticket has been creates successfully
            </p>
                <p>Ticket number RF34567843 </p>
                <div className="message">"You are helping us create a better product"</div>
            </div>
            <a href="/" className="link">Back to main page</a>


        </div>


    )

}

export default Result;
